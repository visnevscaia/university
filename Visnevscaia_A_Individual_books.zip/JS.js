var model = {
    items: [
        { books: "Фэнтези", done: true },
        { books: "Научная Фантастика", done: false },
        { books: "Роман", done: false },
        { books: "Басни", done: false },
        { books: "Научно-популярная", done: false },
        { books: "Комедия", done: false },
        { books: "Драма", done: false },
        { books: "Трагедия", done: false },
        { books: "Художественная литература", done: false },
        { books: "Философия", done: false },
        { books: "Историческая литература", done: false },
        { books: "Мемуары", done: false },
        { books: "Проза", done: false },
        { books: "Классическая литература", done: false },
        { books: "Мифы", done: false },
        { books: "Зарубежная литература", done: false },
        { books: "Юморески", done: false },
    ]
};
var booksApp = angular.module("MYApp", []);
booksApp.controller("booksController", function($scope) {
    $scope.list = model;

    $scope.change = function() {
        let count = 0;
        $("#myTable input[type=checkbox]").each(function() {
            if ($(this).is(':checked')) {
                count++;
            }

        });
        if (count == 0) {
            $scope.result = "У вас нет любимого жанра книг?";
        } else if (count == 1) {
            $scope.result = "У вас " + count + " любимый жанр книг .";
        } else {
            $scope.result = "У вас " + count + " любимых жанров книг .";
        }
    }
});